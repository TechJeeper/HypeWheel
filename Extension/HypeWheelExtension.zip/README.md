# HypeWheel.app Chrome Extension

Pull unique commenter names from social posts (or names from a Google Sheet) and open them on [Hypewheel](https://hypewheel.app/?list=name1,name2,name3).

## Install (Chrome / Edge)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select this `Extension` folder.

## How to use

1. Open a supported page:
   - **X / Twitter** post (`…/status/…`) with replies visible
   - **Facebook** post with comments open
   - **Instagram** post or reel with comments open
   - **TikTok** video with the comments panel open
   - **Google Sheets** with names in cells
2. Click the **HypeWheel.app** extension icon → **Extract names**.
3. Keep the popup open while it auto-scrolls / clicks “load more” (up to ~1 minute).
4. Review the unique list → **Open in HypeWheel.app**.

That opens `https://hypewheel.app/?title=…&list=…` with every unique name. The wheel title is set from the source platform (e.g. Facebook, TikTok).

## Auto-load behavior

Extract will:
- Find the comments (or sheet) scroll area
- Scroll repeatedly and click “View more / Load more / See more” style controls
- Keep accumulating unique names each pass (so virtualized feeds don’t lose earlier ones)
- Stop when names stop growing for several passes, or after a time limit

## Tips

- Leave the post’s comment panel open (especially Facebook / TikTok) before extracting.
- Google Sheets: type the names column letter in the popup (e.g. **C**), then Extract. Opening the popup can clear the sheet’s selection, so typing the letter is the reliable path.
- You can **Copy list** if you want the names as plain text.
- After updating files, click **Reload** on `chrome://extensions`.
